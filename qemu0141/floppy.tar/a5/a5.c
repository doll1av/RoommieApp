#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main(void){

 int xpid, adj, old, hold;
 int usrprio(int pid, int adjustment, int *oldvalue);
 
 xpid = getpid();
 adj = 123;
 old = 0;
 hold = usrprio(xpid, adj, &old);
 if(hold <= 0){
  fprintf(stderr, "New priority out of range. \n");
 }
 if(hold > 0) {
  fprintf(stderr,"New priority: %d \n", old);
 }
 exit(0);

}
