#include <lib.h>
#include <stdio.h>
int usrprio(int pid, int adjustment, int *oldvalue){

 message m;
 int r;
 
 m.m1_i1 = pid;
 m.m1_i2 = adjustment;

 r = _syscall(MM, 58, &m);
 if(r < 0) return -1;

 adjustment = m.m_type;
 *oldvalue = m.m1_i1;
  
 return r;

}
